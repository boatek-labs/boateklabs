// routes/admin.js
const express = require('express');
const fs = require('fs/promises');
const path = require('path');
const os = require('os');
const rateLimit = require('express-rate-limit');
const multer = require('multer');

const JsonStore = require('../lib/jsonStore');
const admins = require('../lib/admins');
const { createSession, getSession, destroySession, destroySessionsForAdmin } = require('../lib/adminAuth');
const { sendMail, isConfigured: isSmtpConfigured } = require('../lib/mailer');
const { renderEmail } = require('../lib/emailTemplates');

const router = express.Router();

const CONFIG_PATH = path.join(__dirname, '..', 'config', 'site.json');
const TEAM_PATH = path.join(__dirname, '..', 'config', 'team.json');
const SESSION_COOKIE = 'boatek_admin_session';

const SUBMISSION_STORES = {
  'project-inquiries': new JsonStore(path.join(__dirname, '..', 'data', 'project-inquiries.json')),
  'career-applications': new JsonStore(path.join(__dirname, '..', 'data', 'career-applications.json')),
  'collaboration-requests': new JsonStore(path.join(__dirname, '..', 'data', 'collaboration-requests.json')),
  'general-inquiries': new JsonStore(path.join(__dirname, '..', 'data', 'general-inquiries.json')),
  subscribers: new JsonStore(path.join(__dirname, '..', 'data', 'subscribers.json')),
  messages: new JsonStore(path.join(__dirname, '..', 'data', 'messages.json'))
};

const projectsStore = new JsonStore(path.join(__dirname, '..', 'content', 'projects.json'));
const journalStore = new JsonStore(path.join(__dirname, '..', 'content', 'journal.json'));
const pageviewsStore = new JsonStore(path.join(__dirname, '..', 'data', 'pageviews.json'));
const newsletterCampaignsStore = new JsonStore(path.join(__dirname, '..', 'data', 'newsletter-campaigns.json'));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts — please wait before trying again.' }
});

const UPLOAD_DIR = path.join(__dirname, '..', 'public', 'uploads');
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safeName = 'upload-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8) + ext;
      cb(null, safeName);
    }
  }),
  limits: { fileSize: 3 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowed.includes(file.mimetype)) {
      return cb(new Error('Only JPG, PNG, WEBP, or GIF images are allowed.'));
    }
    cb(null, true);
  }
});

function requireAdmin(req, res, next) {
  const token = req.cookies ? req.cookies[SESSION_COOKIE] : null;
  const session = getSession(token);
  if (!session) return res.status(401).json({ error: 'Not authenticated.' });
  req.adminSession = session;
  next();
}
// Reserved for actions that must always stay with the founder tier, no
// matter what permissions an editor account might hold — managing other
// admin accounts is the one thing that can't be delegated.
function requireSuper(req, res, next) {
  if (!req.adminSession || req.adminSession.role !== 'super') {
    return res.status(403).json({ error: 'This action requires a super admin account.' });
  }
  next();
}
// For everything else: a super account always passes; an editor account
// passes only if they've been explicitly granted this permission key.
function requirePermission(key) {
  return (req, res, next) => {
    if (!req.adminSession) return res.status(401).json({ error: 'Not authenticated.' });
    if (req.adminSession.role === 'super') return next();
    if ((req.adminSession.permissions || []).includes(key)) return next();
    return res.status(403).json({ error: `Your account doesn't have edit access to ${key}.` });
  };
}

function toCsv(rows) {
  if (!rows.length) return '';
  const columns = Array.from(rows.reduce((set, row) => {
    Object.keys(row).forEach((k) => set.add(k));
    return set;
  }, new Set()));

  function escapeCell(value) {
    if (value === null || value === undefined) return '';
    const str = typeof value === 'object' ? JSON.stringify(value) : String(value);
    if (/[",\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
    return str;
  }

  const header = columns.map(escapeCell).join(',');
  const lines = rows.map((row) => columns.map((c) => escapeCell(row[c])).join(','));
  return [header, ...lines].join('\n');
}

// ============================================================ AUTH ============================================================

router.post('/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }
  const admin = await admins.findByEmail(email);
  if (!admin || !admins.verifyPassword(password, admin.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  const token = createSession(admin);
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 12
  });
  res.json({ ok: true, admin: admins.toPublic(admin) });
});

router.post('/logout', (req, res) => {
  const token = req.cookies ? req.cookies[SESSION_COOKIE] : null;
  destroySession(token);
  res.clearCookie(SESSION_COOKIE);
  res.json({ ok: true });
});

router.get('/session', async (req, res) => {
  const token = req.cookies ? req.cookies[SESSION_COOKIE] : null;
  const session = getSession(token);
  if (!session) return res.json({ authenticated: false });
  const admin = await admins.findById(session.adminId);
  if (!admin) return res.json({ authenticated: false });
  res.json({ authenticated: true, admin: admins.toPublic(admin) });
});

router.use(requireAdmin);

router.get('/me', async (req, res) => {
  const admin = await admins.findById(req.adminSession.adminId);
  res.json(admins.toPublic(admin));
});

// ============================================================ ADMIN ACCOUNTS (owner-only) ============================================================

router.get('/admins', requireSuper, async (req, res) => {
  res.json(await admins.listPublic());
});

router.post('/admins', requireSuper, async (req, res) => {
  const { name, email, password, role, permissions } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }
  try {
    const admin = await admins.createAdmin({ name, email, password, role, permissions });
    res.status(201).json(admins.toPublic(admin));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.patch('/admins/:id/permissions', requireSuper, async (req, res) => {
  const { permissions } = req.body || {};
  const result = await admins.updateAdminPermissions(req.params.id, permissions);
  if (!result.ok) return res.status(400).json({ error: result.error });
  res.json({ ok: true, admin: admins.toPublic(result.admin) });
});

router.get('/permissions-catalog', requireSuper, (req, res) => {
  res.json({ permissions: admins.VALID_PERMISSIONS });
});

router.delete('/admins/:id', requireSuper, async (req, res) => {
  if (req.params.id === req.adminSession.adminId) {
    return res.status(400).json({ error: 'You cannot delete your own account while logged in as it.' });
  }
  const result = await admins.deleteAdmin(req.params.id);
  if (!result.ok) return res.status(400).json({ error: result.error });
  destroySessionsForAdmin(req.params.id);
  res.json({ ok: true });
});

// ============================================================ OVERVIEW ============================================================

router.get('/overview', (req, res) => {
  const hostGuesses = [
    ['Render', process.env.RENDER],
    ['Railway', process.env.RAILWAY_ENVIRONMENT],
    ['Fly.io', process.env.FLY_APP_NAME],
    ['Vercel', process.env.VERCEL],
    ['Heroku', process.env.DYNO],
    ['Koyeb', process.env.KOYEB_APP_ID],
    ['AWS (Elastic Beanstalk)', process.env.EB_ENVIRONMENT_NAME],
    ['Docker (generic)', process.env.DOCKER_CONTAINER]
  ];
  const detected = hostGuesses.find(([, value]) => !!value);
  const hostingEnvironment = detected ? detected[0] : 'Local / unrecognized host';

  res.json({
    hostingEnvironment,
    nodeEnv: process.env.NODE_ENV || 'development',
    nodeVersion: process.version,
    platform: os.platform(),
    arch: os.arch(),
    uptimeSeconds: Math.round(process.uptime()),
    memoryUsageMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
    smtpConfigured: isSmtpConfigured(),
    port: process.env.PORT || 3000,
    serverTime: new Date().toISOString()
  });
});

// ============================================================ ANALYTICS ============================================================

router.get('/analytics', async (req, res) => {
  try {
    const weekBuckets = 8;
    const now = Date.now();
    const weekMs = 7 * 24 * 60 * 60 * 1000;

    function bucketLabel(offsetWeeks) {
      const d = new Date(now - offsetWeeks * weekMs);
      return d.toISOString().slice(0, 10);
    }

    const submissionTypes = ['project-inquiries', 'career-applications', 'collaboration-requests', 'general-inquiries'];
    const perWeek = {};
    for (const type of submissionTypes) {
      const rows = await SUBMISSION_STORES[type].readAll();
      const buckets = new Array(weekBuckets).fill(0);
      rows.forEach((r) => {
        const ts = new Date(r.receivedAt).getTime();
        const weeksAgo = Math.floor((now - ts) / weekMs);
        if (weeksAgo >= 0 && weeksAgo < weekBuckets) {
          buckets[weekBuckets - 1 - weeksAgo]++;
        }
      });
      perWeek[type] = buckets;
    }
    const weekLabels = [];
    for (let i = weekBuckets - 1; i >= 0; i--) weekLabels.push(bucketLabel(i));

    const projectInquiries = await SUBMISSION_STORES['project-inquiries'].readAll();
    const typeBreakdown = {};
    projectInquiries.forEach((r) => {
      const t = r.projectType || 'Not specified';
      typeBreakdown[t] = (typeBreakdown[t] || 0) + 1;
    });

    const subscribers = await SUBMISSION_STORES.subscribers.readAll();
    const messages = await SUBMISSION_STORES.messages.readAll();

    let pageviews = [];
    try {
      pageviews = await pageviewsStore.readAll();
    } catch {
      pageviews = [];
    }
    const last30 = pageviews.filter((p) => now - new Date(p.timestamp).getTime() < 30 * 24 * 60 * 60 * 1000);
    const pathCounts = {};
    last30.forEach((p) => { pathCounts[p.path] = (pathCounts[p.path] || 0) + 1; });
    const topPaths = Object.entries(pathCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([p, c]) => ({ path: p, count: c }));
    const uniqueVisitors30d = new Set(last30.map((p) => p.visitorHash)).size;

    res.json({
      weekLabels,
      submissionsPerWeek: perWeek,
      projectTypeBreakdown: typeBreakdown,
      totals: {
        projectInquiries: projectInquiries.length,
        subscribers: subscribers.length,
        messages: messages.length
      },
      pageviews: {
        totalLast30Days: last30.length,
        uniqueVisitorsLast30Days: uniqueVisitors30d,
        topPaths
      }
    });
  } catch (err) {
    console.error('[admin] analytics failed:', err);
    res.status(500).json({ error: 'Could not compute analytics.' });
  }
});

// ============================================================ SITE CONFIG ============================================================

router.get('/config', async (req, res) => {
  try {
    const raw = await fs.readFile(CONFIG_PATH, 'utf-8');
    res.json(JSON.parse(raw));
  } catch (err) {
    res.status(500).json({ error: 'Could not read site config.' });
  }
});

router.put('/config', requirePermission('config'), async (req, res) => {
  const incoming = req.body || {};
  const allowedKeys = ['social', 'contactEmail', 'supportEmail', 'statusMessage', 'location'];
  const sanitized = {};
  for (const key of allowedKeys) {
    if (incoming[key] !== undefined) sanitized[key] = incoming[key];
  }
  try {
    const raw = await fs.readFile(CONFIG_PATH, 'utf-8');
    const current = JSON.parse(raw);
    const next = { ...current, ...sanitized };
    await fs.writeFile(CONFIG_PATH, JSON.stringify(next, null, 2), 'utf-8');
    res.json({ ok: true, config: next });
  } catch (err) {
    console.error('[admin] failed to write site config:', err);
    res.status(500).json({ error: 'Could not save site config.' });
  }
});

// ============================================================ TEAM ============================================================

router.get('/team', async (req, res) => {
  try {
    const raw = await fs.readFile(TEAM_PATH, 'utf-8');
    res.json(JSON.parse(raw));
  } catch (err) {
    res.status(500).json({ error: 'Could not read team data.' });
  }
});

router.put('/team', requirePermission('team'), async (req, res) => {
  const incoming = req.body;
  if (!Array.isArray(incoming)) {
    return res.status(400).json({ error: 'Team data must be an array of team members.' });
  }
  for (const member of incoming) {
    if (!member.id || !member.name || !member.role) {
      return res.status(400).json({ error: 'Each team member needs at least an id, name, and role.' });
    }
  }
  try {
    await fs.writeFile(TEAM_PATH, JSON.stringify(incoming, null, 2), 'utf-8');
    res.json({ ok: true, team: incoming });
  } catch (err) {
    console.error('[admin] failed to write team data:', err);
    res.status(500).json({ error: 'Could not save team data.' });
  }
});

// ============================================================ PROJECTS CMS ============================================================

router.get('/projects', async (req, res) => {
  res.json(await projectsStore.readAll());
});

router.post('/projects', requirePermission('projects'), async (req, res) => {
  const { title, category, description } = req.body || {};
  if (!title || !category || !description) {
    return res.status(400).json({ error: 'Title, category, and description are required.' });
  }
  const record = {
    id: 'proj-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    title, category, description,
    techStack: Array.isArray(req.body.techStack) ? req.body.techStack : [],
    featured: !!req.body.featured,
    link: req.body.link || '',
    githubOrg: req.body.githubOrg || '',
    thumbnailUrl: req.body.thumbnailUrl || '',
    thumbnailVariant: req.body.thumbnailVariant || 'a',
    images: Array.isArray(req.body.images) ? req.body.images : [],
    clientPortal: req.body.clientPortal || { enabled: false, accessCode: '', updates: [] },
    createdAt: new Date().toISOString()
  };
  await projectsStore.append(record);
  res.status(201).json(record);
});

router.put('/projects/:id', requirePermission('projects'), async (req, res) => {
  const updated = await projectsStore.updateById(req.params.id, req.body || {});
  if (!updated) return res.status(404).json({ error: 'Project not found.' });
  res.json(updated);
});

router.delete('/projects/:id', requirePermission('projects'), async (req, res) => {
  const removed = await projectsStore.removeById(req.params.id);
  if (!removed) return res.status(404).json({ error: 'Project not found.' });
  res.json({ ok: true });
});

// ============================================================ JOURNAL CMS ============================================================

router.get('/journal', async (req, res) => {
  res.json(await journalStore.readAll());
});

router.post('/journal', requirePermission('journal'), async (req, res) => {
  const { title, slug, excerpt, body } = req.body || {};
  if (!title || !slug || !excerpt || !body) {
    return res.status(400).json({ error: 'Title, slug, excerpt, and body are required.' });
  }
  const existing = await journalStore.readAll();
  if (existing.some((p) => p.slug === slug)) {
    return res.status(400).json({ error: 'A post with that slug already exists.' });
  }
  const record = {
    id: 'post-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    title, slug, excerpt, body,
    tags: Array.isArray(req.body.tags) ? req.body.tags : [],
    featured: !!req.body.featured,
    publishedAt: req.body.publishedAt || new Date().toISOString()
  };
  await journalStore.append(record);
  res.status(201).json(record);
});

router.put('/journal/:id', requirePermission('journal'), async (req, res) => {
  const updated = await journalStore.updateById(req.params.id, req.body || {});
  if (!updated) return res.status(404).json({ error: 'Post not found.' });
  res.json(updated);
});

router.delete('/journal/:id', requirePermission('journal'), async (req, res) => {
  const removed = await journalStore.removeById(req.params.id);
  if (!removed) return res.status(404).json({ error: 'Post not found.' });
  res.json({ ok: true });
});

// ============================================================ FILE UPLOAD ============================================================

router.post('/upload', requirePermission('projects'), (req, res) => {
  upload.single('file')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });
    res.json({ ok: true, url: '/uploads/' + req.file.filename });
  });
});

// ============================================================ SUBMISSIONS ============================================================

router.get('/data/:type', async (req, res) => {
  const store = SUBMISSION_STORES[req.params.type];
  if (!store) return res.status(404).json({ error: 'Unknown data type.' });
  const all = await store.readAll();
  res.json(all.slice().reverse());
});

router.patch('/data/:type/:id', requirePermission('submissions'), async (req, res) => {
  const store = SUBMISSION_STORES[req.params.type];
  if (!store) return res.status(404).json({ error: 'Unknown data type.' });
  const allowedFields = ['replied', 'note', 'status'];
  const patch = {};
  for (const key of allowedFields) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  const updated = await store.updateById(req.params.id, patch);
  if (!updated) return res.status(404).json({ error: 'Record not found.' });
  res.json(updated);
});

router.delete('/data/:type/:id', requirePermission('submissions'), async (req, res) => {
  const store = SUBMISSION_STORES[req.params.type];
  if (!store) return res.status(404).json({ error: 'Unknown data type.' });
  const removed = await store.removeById(req.params.id);
  if (!removed) return res.status(404).json({ error: 'Record not found.' });
  res.json({ ok: true });
});

router.get('/export/:type', async (req, res) => {
  const store = SUBMISSION_STORES[req.params.type];
  if (!store) return res.status(404).json({ error: 'Unknown data type.' });
  const rows = await store.readAll();
  const csv = toCsv(rows);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.type}.csv"`);
  res.send(csv);
});

// ============================================================ NEWSLETTER ============================================================

router.post('/newsletter/send', requirePermission('newsletter'), async (req, res) => {
  const { subject, body } = req.body || {};
  if (!subject || !body) {
    return res.status(400).json({ error: 'Subject and body are required.' });
  }
  const subscribers = await SUBMISSION_STORES.subscribers.readAll();
  if (subscribers.length === 0) {
    return res.status(400).json({ error: 'There are no subscribers to send to yet.' });
  }
  const bccList = subscribers.map((s) => s.email);

  try {
    await sendMail({
      to: process.env.CONTACT_TO_EMAIL || 'hello@boateklabs.com',
      subject,
      text: body,
      html: renderEmail({
        eyebrow: 'Boatek Labs Newsletter',
        title: subject,
        intro: '',
        fields: [],
        longFieldLabel: '',
        longFieldValue: body
      }),
      bcc: bccList
    });
    await newsletterCampaignsStore.append({
      id: 'campaign-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      subject,
      body,
      sentTo: bccList.length,
      sentAt: new Date().toISOString(),
      sentBy: req.adminSession.adminId
    });
    res.json({ ok: true, sentTo: bccList.length });
  } catch (err) {
    console.error('[admin] newsletter send failed:', err);
    res.status(500).json({ error: 'Could not send the newsletter right now.' });
  }
});

router.get('/newsletter/campaigns', async (req, res) => {
  const campaigns = await newsletterCampaignsStore.readAll();
  res.json(campaigns.slice().reverse());
});

module.exports = router;
