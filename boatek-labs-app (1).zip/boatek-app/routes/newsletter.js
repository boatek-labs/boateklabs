// routes/newsletter.js
const express = require('express');
const path = require('path');
const JsonStore = require('../lib/jsonStore');

const router = express.Router();
const store = new JsonStore(path.join(__dirname, '..', 'data', 'subscribers.json'));

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

router.post('/', async (req, res) => {
  const { email, website } = req.body || {};

  // Honeypot — see routes/inquiries.js for the same pattern explained.
  if (website) {
    console.log('[newsletter] honeypot triggered — silently discarding submission.');
    return res.status(201).json({ ok: true });
  }

  if (!email || !EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Please provide a valid email address.' });
  }

  const normalized = String(email).trim().toLowerCase();

  try {
    const existing = await store.readAll();
    if (existing.some((s) => s.email === normalized)) {
      return res.status(200).json({ ok: true, alreadySubscribed: true });
    }
    await store.append({ id: makeId(), email: normalized, subscribedAt: new Date().toISOString() });
  } catch (err) {
    console.error('[newsletter] failed to persist subscriber:', err);
    return res.status(500).json({ error: 'Could not subscribe right now. Please try again shortly.' });
  }

  return res.status(201).json({ ok: true });
});

module.exports = router;
